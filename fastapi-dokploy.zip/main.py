from fastapi import FastAPI
from datetime import datetime

app = FastAPI(title="Dokploy Test API")


@app.get("/")
async def root():
    return {
        "message": "Hello from Dokploy!",
        "status": "running",
        "timestamp": datetime.now().isoformat()
    }


@app.get("/health")
async def health():
    return {"status": "healthy"}


@app.get("/info")
async def info():
    return {
        "app": "FastAPI Test App",
        "version": "1.0.0",
        "framework": "FastAPI"
    }
